var settings;

(function() {
    'use strict';

    settings = {
      title:        'drive-in',
      baseurl:       '', // your base url useful for subpath, if any.
      
      sharing_link: 'https://drive.google.com/folderview?id=XXXXYYYYZZZZ&usp=sharing',

      CLIENT_ID:    'YOURCLIENTID.apps.googleusercontent.com',
      SCOPES:       'https://www.googleapis.com/auth/drive',
    };
})();
